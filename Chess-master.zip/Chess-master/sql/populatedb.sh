docker exec -i mysql_db sh -c 'exec mysql -uroot -pplatas76' < ./sql/chess_db.sql
