package core.sebas;

/**
 * Hello world!
 *
 */
public abstract class App 
{
    public static void main( final String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
