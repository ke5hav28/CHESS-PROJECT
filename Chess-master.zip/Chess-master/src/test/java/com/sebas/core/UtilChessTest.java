package com.sebas.core;

import junit.framework.TestCase;

public class UtilChessTest extends TestCase {
	
	@Override
	protected void setUp() throws Exception {
		
	}
	
    public void testRandomPiece()
    {
        assertTrue( true );
    }
	
}
