gradlew sonarqube -Dsonar.projectKey=chess -Dsonar.host.url=http://localhost:9000 -Dsonar.login={TOKEN}
