keytool -keystore target/chess-1.1.jar -keypass revuelta -storepass marchetti -alias chess -genkeypair -dname "cn=Sebas, ou=Chess, o=Vulnerable, S=Madrid, c=Spain" -validity 60
